# coding:utf-8
import pymongo


class MongoUtils:

    name = 'unname'

    def __init__(self, name):
        self.name = name

    @staticmethod
    def getDb():
        # 192.168.1.19
        # 3520f327-1cb2-4a94-9cee-9c6a9e4b8695
        client = pymongo.MongoClient(host="192.168.1.19", port=27017)
        db = client['3520f327-1cb2-4a94-9cee-9c6a9e4b8695']
        return db

    @staticmethod
    def getCol(db, colName):
        return db[colName]

    @staticmethod
    def insert(collection, infomation):
        collection.insert(infomation)

    @staticmethod
    def updateOrInsert(collection, infomation):
        collection.update(infomation,infomation,True)

    @staticmethod
    def find(collection, spec):
        collection.find(spec)
