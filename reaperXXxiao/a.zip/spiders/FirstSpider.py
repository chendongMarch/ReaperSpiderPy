# coding:utf-8
import scrapy
from MongoUtils import *
from scrapy import Request
from scrapy.selector import Selector


class FirstSpider(scrapy.spiders.Spider):
    name = "dmoz"
    allowed_domains = ["m.xxxiao.com"]
    start_urls = [
        "http://m.xxxiao.com",
        "http://m.xxxiao.com/cat/xinggan",
        "http://m.xxxiao.com/cat/shaonv",
        "http://m.xxxiao.com/cat/mrxt",
        "http://m.xxxiao.com/cat/wmxz",
        "http://m.xxxiao.com/cat/wallpaper"
    ]

    def make_requests_from_url(self, url):
        return Request(url, dont_filter=True, meta={
            'dont_redirect': True,
            'handle_httpstatus_list': [301, 302]
        })

    @staticmethod
    def code(unicode):
        return unicode.encode().replace('-760x500.jpg', '.jpg')

    db = MongoUtils.getDb()
    collection = MongoUtils.getCol(db, 'tb_new')
    coll_album = MongoUtils.getCol(db, 'album')
    coll_album_detail = MongoUtils.getCol(db, 'album_detail')

    def parse_detail(self, response):
        selector = Selector(response)
        album_link = selector.xpath('//head/link[@rel="canonical"]/@href').extract()[0]
        for line in selector.xpath("//div[@class='gallery-icon portrait']"):
            detail_src = line.xpath('a[1]/@href').extract()[0]
            dict = {}
            dict['album_link'] = album_link
            dict['detail_src'] = detail_src
            MongoUtils.updateOrInsert(self.coll_album_detail, dict)

    def parse(self, response):
        print 'url is ' + response.url
        selector = Selector(response)
        for line in selector.xpath('//div[@class="post-thumb"]'):
            album_link = self.code(line.xpath('a[1]/@href').extract()[0])
            yield Request(album_link, callback=self.parse_detail)
            pic_src = self.code(line.xpath('a[1]/img/@src').extract()[0])
            pic_desc = self.code(line.xpath('a[1]/img/@alt').extract()[0])
            dict = {}
            dict['album_link'] = album_link
            dict['pic_src'] = pic_src
            dict['pic_desc'] = pic_desc
            dict['album_type'] = response.url
            MongoUtils.updateOrInsert(self.coll_album, dict)